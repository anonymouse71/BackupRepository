/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.1.13-MariaDB : Database - employeemanagementdb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`employeemanagementdb` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `employeemanagementdb`;

/*Table structure for table `employee_info` */

DROP TABLE IF EXISTS `employee_info`;

CREATE TABLE `employee_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `employee_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `employee_email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `employee_contact_no` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `employee_designation` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `employee_info` */

insert  into `employee_info`(`id`,`employee_name`,`employee_id`,`employee_email`,`employee_contact_no`,`employee_designation`,`created_at`,`updated_at`) values (1,'Irfan Kazi','IK-001','irfan@gmail.com','01971751971','Junior Executive','2016-06-14 12:41:21','2016-06-14 06:41:21'),(4,'Sultan Mahmoud Quraish','SMQ-003','sultan@gmail.com','01877645890','Associate','2016-06-14 05:56:02','2016-06-14 05:56:02'),(5,'Terbina Shadana','TS-004','shadana@gmail.com','01876456789','Executive','2016-06-14 07:12:20','2016-06-14 07:12:20');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`email`,`password`,`created_at`,`updated_at`,`remember_token`) values (1,'Irfan Kazi','irfan@gmail.com','$2y$10$ylA39Yaxk.92fDCg3uZcauVc2BcyMayOohlSaOWsCBVXmb8Hp48fK','2016-06-29 10:13:32','2016-06-29 04:13:32','carlgTtBFe5EHU4He5TSEmqdElrDBE8FRFJx7RL7ZWPAfuUG2ZyIMDIzUb9e'),(2,'Sultan Mahmoud Quraish','sultan@gmail.com','$2y$10$ylA39Yaxk.92fDCg3uZcauVc2BcyMayOohlSaOWsCBVXmb8Hp48fK','2016-06-13 08:57:25','2016-06-13 08:57:25',NULL),(3,'Abir Rahman','abir@gmail.com','$2y$10$.mgTibkOscIq8x8vRBwafuAaZpMr7vpvx1LEC4XFTmJFUcBfjSfP.','2016-06-13 14:59:23','2016-06-13 08:59:23','1hhj2JqYgl5nmbJMpohvzAzO44Zi3fjfceV9xr9IiTCN1nrqBV1mCmonYdja');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
