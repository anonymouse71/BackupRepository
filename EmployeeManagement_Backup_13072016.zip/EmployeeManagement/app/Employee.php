<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    /*
     * Table name
     */
    protected $table = 'employee_info';

    /*
     * Fillable fields for protecting mass assignment vulnerability
     */
//    protected $fillable = [
//        'employee_name',
//        'employee_id',
//        'employee_email',
//        'employee_contact_no',
//        'employee_designation',
//    ];

    /*
     * Eloquent attribute casting
     */
//    protected $casts = [
//        'complete' => 'boolean'
//    ];
}
