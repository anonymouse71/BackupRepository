@extends('default')
@section('title')
Create New Employee
@stop
@section('body')
<div class="wrapper wrapper-white">
    <div class="page-subtitle">
        <h3>Create New Employee</h3>
    </div>
    <div class="row row-wider">
        <div class="col-md-4 col-md-offset-4">
            {!! Form::open(['url' => '/employees',  'role' => 'form']) !!}
            <div class="form-group-one-unit margin-bottom-40">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group form-group-custom">
                            <label>Employee Name</label>
                            <input type="text" name="employee_name" class="form-control" required/>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group form-group-custom">
                            <label>Employee ID</label>
                            <input type="text" name="employee_id" class="form-control"/>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group form-group-custom">
                            <label>Employee Email</label>
                            <input type="text"  name="employee_email" class="form-control"/>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group form-group-custom">
                            <label>Employee Contact No</label>
                            <input type="text"  name="employee_contact_no" class="form-control"/>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group form-group-custom">
                            <label>Employee Designation</label>
                            <input type="text" name="employee_designation" class="form-control"/>
                        </div>
                    </div>

                </div>

            </div>
            <div class="row">
                <div class="col-md-12">
                    <button class="btn btn-danger pull-right">Save</button>
                </div>
            </div>
            {!! Form::close() !!}
            </div>
    </div>
</div>
@stop