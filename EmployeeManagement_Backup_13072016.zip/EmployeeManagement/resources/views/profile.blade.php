@extends('default')
@section('title')
Profile :: {{Auth::user()->name}}
@stop
@if(Session::has('sucess'))
<div class="alert alert-info alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
    {{Session::get('sucess')}}
</div>
@endif
<div class="container">
    <div>
        @if(Auth::check())
        <p>Welcome to your profile page {{Auth::user()->name}}</p>
        @endif
    </div>
    <div class="page-title">
        <a href="{{URL::to('employees')}}"><button class="btn btn-primary btn-clean">View Employee List</button></a>
    </div>
</div>