@extends('default')
@section('title')
Edit Employee Information
@stop
@section('body')
<div class="wrapper wrapper-white">
    <div class="page-subtitle">
        <h3>Edit Employee Information</h3>
    </div>
    <div class="row row-wider">
        <div class="col-md-4 col-md-offset-1">
        {!! Form::model($editdata,['url' => '/employees/'.$editdata->id, 'method' => 'PUT']) !!}
        <div class="form-group">
            <label for="employee_name">Employee Name</label>
            {!! Form::text('employee_name',null,['class'=>'form-control']) !!}
        </div>

        <div class="form-group">
            <label for="employee_id">Employee ID</label>
            {!! Form::text('employee_id',null,['class'=>'form-control']) !!}
        </div>

        <div class="form-group">
            <label for="employee_email">Employee Email</label>
            {!! Form::text('employee_email',null,['class'=>'form-control']) !!}
        </div>

        <div class="form-group">
            <label for="employee_contact_no">Employee Contact No</label>
            {!! Form::text('employee_contact_no',null,['class'=>'form-control']) !!}
        </div>

        <div class="form-group">
            <label for="employee_designation">Employee Designation</label>
            {!! Form::text('employee_designation',null,['class'=>'form-control']) !!}
        </div>

        <button type="submit" class="btn btn-primary">Save</button>
        <a href="{{ url('/employees') }}" class="btn btn-warning">Cancel</a>

        {!! Form::close() !!}
            </div>
    </div>
</div>
@stop