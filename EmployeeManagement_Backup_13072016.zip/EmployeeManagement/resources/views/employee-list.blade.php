@extends('default')
@section('title')
Employee Information
@stop
@section('body')

<!-- page content -->
<div class="dev-page-content">
    <!-- page content container -->
    <div class="container">


        <!-- page title -->
        <div class="page-title">
            <a href="{{URL::to('employees/create')}}"><button class="btn btn-primary btn-clean">Add New Employee</button></a>
        </div>
        <!-- ./page title -->

        <!-- datatables plugin -->
        <div class="wrapper wrapper-white">
            <div class="page-subtitle">
                <h3>Employee Information</h3>
            </div>

            <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sortable" id="employee_list">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Contact No</th>
                        <th>Designation</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($files as $value)
                    <tr>
                        <td>{{$value->employee_name}}</td>
                        <td>{{$value->employee_id}}</td>
                        <td>{{$value->employee_email}}</td>
                        <td>{{$value->employee_contact_no}}</td>
                        <td>{{$value->employee_designation}}</td>
                        <td>
                            <a href="{{ url('/employees/'.$value->id.'/edit') }}" class="btn btn-warning pull-left">Edit</a>
                            <span class="pull-left">&nbsp;</span>
                            {!! Form::open(['url'=>'/employees/'.$value->id, 'class'=>'pull-left']) !!}
                            {!! Form::hidden('_method', 'DELETE') !!}
                            {!! Form::submit('Delete', ['class' => 'btn btn-danger', 'onclick'=>'return confirm(\'Are you sure?\')']) !!}
                            {!! Form::close() !!}
                        </td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>
               <center> {!! $files->render() !!}</center>
            </div>

        </div>
        <!-- ./datatables plugin -->

    </div>
    <!-- ./page content container -->
</div>
<!-- ./page content -->
<script>
$(document).ready( function () {
$('#employee_list').DataTable();
});
</script>
@stop