<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
 * Default Route
 */

Route::get('/layout', function () {
    return view('Layout.MainLayout');
});

Route::get('/adminlte', function () {
    return view('Layout.AdminLTE');
});

Route::get('/auth/login', function () {
    return view('errors.PleaseLogin');
});

/*
 * Necessary Route
 */
// Login Routes
Route::resource('user', 'UsersController');
Route::get('login', array('as' => 'login', 'uses' => 'UsersController@login'));
Route::post('login', array('as' => 'login', 'uses' => 'UsersController@handleLogin'));
Route::get('/profile', array('as' => 'profile', 'uses' => 'UsersController@profile'));
Route::get('/logout', array('as' => 'logout', 'uses' => 'UsersController@logout'));

// Workflow Routes
Route::get('workflow/BalanceHistory', 'WorkflowController@BalanceHistory');
Route::get('workflow/PurchaseBalance', 'WorkflowController@PurchaseBalance');
Route::post('workflow/PurchaseBalance', 'WorkflowController@BalanceAssign');
Route::post('workflow/PurchaseBalance/search', 'WorkflowController@SearchBalance');
