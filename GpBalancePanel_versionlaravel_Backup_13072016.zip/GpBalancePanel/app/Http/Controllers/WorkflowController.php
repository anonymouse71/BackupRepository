<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Input;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Validator;
class WorkflowController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function BalanceHistory()
    {
        // Laravel Query
        $get_gpcmp_data = DB::table('telco_gw_gpcmp')
                        ->leftJoin('telco_sms_count','telco_gw_gpcmp.masking', '=', 'telco_sms_count.masking')
                        ->select('telco_gw_gpcmp.user_id', DB::raw('SUM(sms_count) as count_value'))
                        ->where('platform','=','GPCMP')
                        ->where('sdate','>','2016-06-27')
                        ->groupBy('telco_gw_gpcmp.user_id')
                        ->get();

        // Raw Query
//        $get_gpcmp_data = DB::select('SELECT SUM(sms_count) AS count_value, telco_gw_gpcmp.user_id FROM telco_gw_gpcmp
//                            LEFT JOIN telco_sms_count
//                            ON telco_gw_gpcmp.masking = telco_sms_count.masking
//                            WHERE platform = "GPCMP"
//                            AND sdate > "2016-06-27"
//                            GROUP BY telco_gw_gpcmp.user_id');

        $balance_history=array();
        $i=0;
        foreach($get_gpcmp_data as $key => $row)
        {
            $user_id = $row->user_id;
            $consumption_balance = $row->count_value;
            $balance_history[$i]['cmp_account_name']= $user_id;
            $balance_history[$i]['consumption_balance']= $consumption_balance;

            // Laravel Query
            $current_balance = DB::table('telco_gw_gpcmp_bal')
                             ->select(DB::raw('SUM(cmp_balance) as cmp_balance'))
                             ->where('cmp_account_name','=',$user_id)
                             ->where('created_at','>','2016-06-28%')
                             ->get();

            // Raw Query
//            $current_balance = DB::select("SELECT SUM(cmp_balance) as cmp_balance FROM telco_gw_gpcmp_bal WHERE cmp_account_name='{$user_id}'");

            $current_balance_value = $current_balance[0]->cmp_balance;
            $balance_history[$i]['current_balance']= ($current_balance_value<=0)? 0:($current_balance_value - $consumption_balance);
            $i++;
        }
        return view('WebPage.BalanceHistory')->with('balance_history',$balance_history);
    }

    public function PurchaseBalance()
    {
        $cmp_account_names = DB::table('telco_gw_gpcmp')->select('user_id')->distinct()->get();
        return view('WebPage.PurchaseBalance')->with('cmp_account_names',$cmp_account_names);
    }

    public function BalanceAssign(Request $request)
    {
        // Validation //
        $validation = Validator::make($request->all(), [
            'cmp_account_name' => 'required',
            'cmp_balance' => 'required',
        ]);

        // Check if it fails //
        if( $validation->fails() ){
            return redirect()->back()->withInput()
                ->with('error', $validation->errors() );
        }

        DB::table('telco_gw_gpcmp_bal')->insert([
            ['cmp_account_name' => $request->input('cmp_account_name'), 'cmp_balance' => $request->input('cmp_balance')]
        ]);
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Balance assigned to ". $request->input('cmp_account_name')." by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Balance Successfully Added!');
        return redirect('workflow/PurchaseBalance');
    }

    public function SearchBalance()
    {
       $cmp_account_name = Input::get('cmp_account_name');
            $cmp_account_data = DB::table('telco_gw_gpcmp_bal')->where('cmp_account_name','=',$cmp_account_name)->orderBy('created_at','desc')->get();
            if($cmp_account_data == NULL)
            {
                Session::flash('error','No Data Found!');
                return redirect('workflow/PurchaseBalance');
            }
            else
            {
                $cmp_account_names = DB::table('telco_gw_gpcmp')->select('user_id')->distinct()->get();
                return view('WebPage.PurchaseBalance')->with('cmp_account_data',$cmp_account_data)->with('cmp_account_names',$cmp_account_names);
            }
    }
}