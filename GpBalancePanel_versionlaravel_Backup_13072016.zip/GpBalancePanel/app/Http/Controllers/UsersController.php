<?php
namespace App\Http\Controllers;
use App\UserType;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Input;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use App\User;
class UsersController extends Controller
{
    public function login()
    {
        return view('WebPage.UserLogin');
    }
    public function handleLogin()
    {
        $data = Input::only(['email', 'password']);
        if(Auth::attempt(['email' => $data['email'], 'password' => $data['password']]))
        {
            $file =base_path().'\loginlog.txt';
            $data_for_log = date("Y-m-d H:i:s")." Logged in by ". Auth::user()->name."\n";
            // Write the contents to the file,
            // using the FILE_APPEND flag to append the content to the end of the file
            // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
            file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
            Session::flash('success','Login Successful!');
            return Redirect::to('/profile');
        }
        else
        {
            Session::flash('error','Username & password combination is incorrect!');
            return Redirect::to('/login')->withInput();
        }
    }

    public function profile()
    {
        return Redirect::to('/workflow/BalanceHistory');
    }

    public function logout()
    {
        if(Auth::check()){
            $file =base_path().'\loginlog.txt';
            $data_for_log = date("Y-m-d H:i:s")." Logged out by ". Auth::user()->name."\n";
            // Write the contents to the file,
            // using the FILE_APPEND flag to append the content to the end of the file
            // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
            file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
            Auth::logout();
        }
        return Redirect::to('/login');
    }

    public function create()
    {
        $user_types = DB::connection('mysql2')->table('user_type')->select('id','title')->get();
        return view('WebPage.UserCreate')->with('user_types',$user_types);
    }

    public function store(Request $request)
    {
        if (User::where('email', '=', Input::get('email'))->exists()) {
            $user_types = DB::connection('mysql2')->table('user_type')->select('id','title')->get();
            Session::flash('error','User already exists!');
            return view('WebPage.UserCreate')->with('user_types',$user_types);
        }
        else
        {
            $user = new User();
            $user->name = $request->input('name');
            $user->email = $request->input('email');
            $user->password = bcrypt($request->input('password'));
            $user->user_type = $request->input('user_type');
            $user->save();
            Auth::login($user);
            return Redirect::to('/profile');
        }
    }
}