<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
 * Default Route
 */

Route::get('/layout', function () {
    return view('Layout.MainLayout');
});

Route::get('/adminlte', function () {
    return view('Layout.AdminLTE');
});

Route::get('/auth/login', function () {
    return view('errors.PleaseLogin');
});

/*
 * Necessary Route
 */
// Login Routes
Route::resource('user', 'UsersController');
Route::get('login', array('as' => 'login', 'uses' => 'UsersController@login'));
Route::post('login', array('as' => 'login', 'uses' => 'UsersController@handleLogin'));
Route::get('/profile', array('as' => 'profile', 'uses' => 'UsersController@profile'));
Route::get('/logout', array('as' => 'logout', 'uses' => 'UsersController@logout'));

// Grameenphone Routes
Route::resource('GrameenphoneMasking', 'GrameenphoneMaskingController');
Route::post('GrameenphoneMasking/search', 'GrameenphoneMaskingController@SearchMasking');

// Banglalink Routes
Route::resource('BanglalinkMasking', 'BanglalinkMaskingController');
Route::post('BanglalinkMasking/search', 'BanglalinkMaskingController@SearchMasking');

// Robi Routes
Route::resource('RobiMasking', 'RobiMaskingController');
Route::post('RobiMasking/search', 'RobiMaskingController@SearchMasking');

// Airtel Routes
Route::resource('AirtelMasking', 'AirtelMaskingController');
Route::post('AirtelMasking/search', 'AirtelMaskingController@SearchMasking');

// Teletalk Routes
Route::resource('TeletalkMasking', 'TeletalkMaskingController');
Route::post('TeletalkMasking/search', 'TeletalkMaskingController@SearchMasking');

// Citycell Routes
Route::resource('CitycellMasking', 'CitycellMaskingController');
Route::post('CitycellMasking/search', 'CitycellMaskingController@SearchMasking');
