<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Controller;
use App\GrameenphoneMasking;
use Validator;
use Input;
use DB;
use File;
use Auth;

class GrameenphoneMaskingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('WebPage.GrameenphoneMasking');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */



//    public function create()
//    {
//        //2. This method relates to the "add new image" view
//        return view('employee-create');
//    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        // Validation //
        $validation = Validator::make($request->all(), [
            'masking' => 'required',
            'telco_masking' => 'required',
            'user_id' => 'required',
            'password' => 'required',
        ]);

        // Check if it fails //
        if( $validation->fails() ){
            return redirect()->back()->withInput()
                ->with('error', $validation->errors() );
        }

        if (GrameenphoneMasking::where('masking', '=', Input::get('masking'))->exists()) {
            Session::flash('error','Masking already exists!');
            return view('WebPage.GrameenphoneMasking');
        }

        $grameen_phone_masking = new GrameenphoneMasking;


        // save data into database //
        $grameen_phone_masking->masking = $request->input('masking');
        $grameen_phone_masking->telco_masking = $request->input('telco_masking');
        $grameen_phone_masking->user_id = $request->input('user_id');
        $grameen_phone_masking->password = $request->input('password');
        $grameen_phone_masking->save();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking ". Input::get('masking'). " on Grameenphone Masking is Created by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Created!');
        return redirect('GrameenphoneMasking');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        return view('WebPage.GrameenphoneMasking');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //4. This method relates to the "edit image" view
        $editdata = GrameenphoneMasking::find($id);
        return view('WebPage.Edit-GrameenphoneMasking')->with('editdata', $editdata);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        // Validation //
        $validation = Validator::make($request->all(), [
            'masking' => 'required',
            'telco_masking' => 'required',
            'user_id' => 'required',
            'password' => 'required',
        ]);

        // Check if it fails //
        if( $validation->fails() ){
            return redirect()->back()->withInput()
                ->with('error', $validation->errors() );
            $editdata = GrameenphoneMasking::find($id);
            return view('WebPage.Edit-GrameenphoneMasking')->with('editdata', $editdata);
        }

        $editdata = GrameenphoneMasking::findOrFail($id);
        $editdata->masking = $request->input('masking');
        $editdata->telco_masking = $request->input('telco_masking');
        $editdata->user_id = $request->input('user_id');
        $editdata->password = $request->input('password');
        $editdata->save();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking with ID no. ". $id. " on Grameenphone Masking is Updated by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Updated!');
        return $this->index();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        $grameen_phone_masking = GrameenphoneMasking::find($id);
        $grameen_phone_masking->delete();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking with ID no. ". $id. " on Grameenphone Masking is Deleted by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Deleted!');
        return redirect('/GrameenphoneMasking');
    }

    public function SearchMasking()
    {
        $masking = Input::get('masking');
        $user_id = Input::get('user_id');
        if($masking== NULL && $user_id == NULL)
        {
            Session::flash('error','Please provide either Masking or User ID!');
            return redirect('GrameenphoneMasking');
        }
        elseif($masking!= NULL && $user_id!= NULL)
        {
            $grameen_phone_masking_search_result = DB::table('telco_gw_gpcmp')->where('masking','=',$masking)->where('user_id','=',$user_id)->get();
            if($grameen_phone_masking_search_result == NULL)
            {
                Session::flash('error','Sorry, No Data Found!');
                return redirect('GrameenphoneMasking');
            }
            else
            {
                return view('WebPage.GrameenphoneMasking')->with('grameen_phone_masking_search_result',$grameen_phone_masking_search_result);
            }
        }
        elseif($masking!= NULL)
        {
            $grameen_phone_masking_search_result = DB::table('telco_gw_gpcmp')->where('masking','=',$masking)->get();
            if($grameen_phone_masking_search_result == NULL)
            {
                Session::flash('error','Sorry, No Data Found!');
                return redirect('GrameenphoneMasking');
            }
            else
            {
            return view('WebPage.GrameenphoneMasking')->with('grameen_phone_masking_search_result',$grameen_phone_masking_search_result);
            }
        }
        elseif($user_id!= NULL)
        {
            $grameen_phone_masking_search_result = DB::table('telco_gw_gpcmp')->where('user_id','=',$user_id)->get();
            if($grameen_phone_masking_search_result == NULL)
            {
                Session::flash('error','Sorry, No Data Found!');
                return redirect('GrameenphoneMasking');
            }
            else
            {
            return view('WebPage.GrameenphoneMasking')->with('grameen_phone_masking_search_result',$grameen_phone_masking_search_result);
            }
        }
    }
}
