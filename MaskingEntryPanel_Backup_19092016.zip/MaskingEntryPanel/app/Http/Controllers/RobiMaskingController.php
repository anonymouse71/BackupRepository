<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Controller;
use App\RobiMasking;
use Validator;
use Input;
use DB;
use File;
use Auth;

class RobiMaskingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('WebPage.RobiMasking');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */



//    public function create()
//    {
//        //2. This method relates to the "add new image" view
//        return view('employee-create');
//    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        // Validation //
        $validation = Validator::make($request->all(), [
            'masking' => 'required',
            'telco_masking' => 'required',
        ]);

        // Check if it fails //
        if( $validation->fails() ){
            return redirect()->back()->withInput()
                ->with('error', $validation->errors() );
        }

        if (RobiMasking::where('masking', '=', Input::get('masking'))->exists()) {
            Session::flash('error','Masking already exists!');
            return view('WebPage.RobiMasking');
        }

        $robi_masking = new RobiMasking;


        // save data into database //
        $robi_masking->masking = $request->input('masking');
        $robi_masking->telco_masking = $request->input('telco_masking');
        $robi_masking->save();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking ". Input::get('masking'). " on Robi Masking is Created by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Created!');
        return redirect('RobiMasking');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        return view('WebPage.RobiMasking');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //4. This method relates to the "edit image" view
        $editdata = RobiMasking::find($id);
        return view('WebPage.Edit-RobiMasking')->with('editdata', $editdata);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        // Validation //
        $validation = Validator::make($request->all(), [
            'masking' => 'required',
            'telco_masking' => 'required',
        ]);

        // Check if it fails //
        if( $validation->fails() ){
            return redirect()->back()->withInput()
                ->with('error', $validation->errors() );
            $editdata = RobiMasking::find($id);
            return view('WebPage.Edit-RobiMasking')->with('editdata', $editdata);
        }

        $editdata = RobiMasking::findOrFail($id);
        $editdata->masking = $request->input('masking');
        $editdata->telco_masking = $request->input('telco_masking');
        $editdata->save();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking with ID no. ". $id. " on Robi Masking is Updated by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Updated!');
        return $this->index();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        $robi_masking = RobiMasking::find($id);
        $robi_masking->delete();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking with ID no. ". $id. " on Robi Masking is Deleted by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Deleted!');
        return redirect('/RobiMasking');
    }

    public function SearchMasking()
    {
        $masking = Input::get('masking');
        if($masking== NULL)
        {
            Session::flash('error','Please provide Masking!');
            return redirect('RobiMasking');
        }
        else
        {
            $robi_masking_search_result = DB::table('telco_gw_robi')->where('masking','=',$masking)->get();
            if($robi_masking_search_result == NULL)
            {
                Session::flash('error','Sorry, No Data Found!');
                return redirect('RobiMasking');
            }
            else
            {
                return view('WebPage.RobiMasking')->with('robi_masking_search_result',$robi_masking_search_result);
            }
        }
    }
}
