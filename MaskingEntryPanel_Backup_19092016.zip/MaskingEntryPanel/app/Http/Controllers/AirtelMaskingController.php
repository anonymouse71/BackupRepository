<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Controller;
use App\AirtelMasking;
use Validator;
use Input;
use DB;
use File;
use Auth;

class AirtelMaskingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('WebPage.AirtelMasking');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */



//    public function create()
//    {
//        //2. This method relates to the "add new image" view
//        return view('employee-create');
//    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        // Validation //
        $validation = Validator::make($request->all(), [
            'masking' => 'required',
            'telco_masking' => 'required',
            'user_id' => 'required',
            'password' => 'required',
            'map_msisdn' => 'required',
        ]);

        // Check if it fails //
        if( $validation->fails() ){
            return redirect()->back()->withInput()
                ->with('error', $validation->errors() );
        }

        if (AirtelMasking::where('masking', '=', Input::get('masking'))->exists()) {
            Session::flash('error','Masking already exists!');
            return view('WebPage.AirtelMasking');
        }

        $airtel_masking = new AirtelMasking;


        // save data into database //
        $airtel_masking->masking = $request->input('masking');
        $airtel_masking->telco_masking = $request->input('telco_masking');
        $airtel_masking->user_id = $request->input('user_id');
        $airtel_masking->password = $request->input('password');
        $airtel_masking->map_msisdn = $request->input('map_msisdn');
        $airtel_masking->save();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking ". Input::get('masking'). " on Airtel Masking is Created by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Created!');
        return redirect('AirtelMasking');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        return view('WebPage.AirtelMasking');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //4. This method relates to the "edit image" view
        $editdata = AirtelMasking::find($id);
        return view('WebPage.Edit-AirtelMasking')->with('editdata', $editdata);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        // Validation //
        $validation = Validator::make($request->all(), [
            'masking' => 'required',
            'telco_masking' => 'required',
            'user_id' => 'required',
            'password' => 'required',
            'map_msisdn' => 'required',
        ]);

        // Check if it fails //
        if( $validation->fails() ){
            return redirect()->back()->withInput()
                ->with('error', $validation->errors() );
            $editdata = AirtelMasking::find($id);
            return view('WebPage.Edit-AirtelMasking')->with('editdata', $editdata);
        }

        $editdata = AirtelMasking::findOrFail($id);
        $editdata->masking = $request->input('masking');
        $editdata->telco_masking = $request->input('telco_masking');
        $editdata->user_id = $request->input('user_id');
        $editdata->password = $request->input('password');
        $editdata->map_msisdn = $request->input('map_msisdn');
        $editdata->save();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking with ID no. ". $id. " on Airtel Masking is Updated by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Updated!');
        return $this->index();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        $airtel_masking = AirtelMasking::find($id);
        $airtel_masking->delete();
        $file =base_path().'\worklog.txt';
        $data_for_log = date("Y-m-d H:i:s")." Masking with ID no. ". $id. " on Airtel Masking is Deleted by ". Auth::user()->name."\n";
        // Write the contents to the file,
        // using the FILE_APPEND flag to append the content to the end of the file
        // and the LOCK_EX flag to prevent anyone else writing to the file at the same time
        file_put_contents($file, $data_for_log, FILE_APPEND | LOCK_EX);
        Session::flash('success','Masking Successfully Deleted!');
        return redirect('/AirtelMasking');
    }

    public function SearchMasking()
    {
        $masking = Input::get('masking');
        if($masking== NULL)
        {
            Session::flash('error','Please provide Masking!');
            return redirect('AirtelMasking');
        }
        else
        {
            $airtel_masking_search_result = DB::table('telco_gw_airtel')->where('masking','=',$masking)->get();
            if($airtel_masking_search_result == NULL)
            {
                Session::flash('error','Sorry, No Data Found!');
                return redirect('AirtelMasking');
            }
            else
            {
                return view('WebPage.AirtelMasking')->with('airtel_masking_search_result',$airtel_masking_search_result);
            }
        }
    }
}
