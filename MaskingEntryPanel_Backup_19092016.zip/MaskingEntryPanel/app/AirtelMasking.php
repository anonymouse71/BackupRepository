<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AirtelMasking extends Model
{
    /*
     * Table name
     */
    protected $table = 'telco_gw_airtel';
}