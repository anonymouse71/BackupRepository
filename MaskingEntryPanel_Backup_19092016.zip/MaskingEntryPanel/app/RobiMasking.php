<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RobiMasking extends Model
{
    /*
     * Table name
     */
    protected $table = 'telco_gw_robi';
}