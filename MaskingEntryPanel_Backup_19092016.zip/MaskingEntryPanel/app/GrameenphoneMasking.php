<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GrameenphoneMasking extends Model
{
    /*
     * Table name
     */
    protected $table = 'telco_gw_gpcmp';
}